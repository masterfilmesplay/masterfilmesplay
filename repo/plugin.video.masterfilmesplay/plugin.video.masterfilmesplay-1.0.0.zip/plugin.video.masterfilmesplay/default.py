# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, dandy
ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.masterfilmesplay/')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fundo.jpg'
PATH = 'masterfilmesplay'
VERSION = '1.0.7'
BASEURL = 'http://masterfilmesplay.xyz/'
ART = ADDON_PATH + "resources/icones/"



def Main_menu():
    Menu('[B][COLOR cornflowerblue]Todos Filmes[/COLOR][/B]',BASEURL+'filmes/',5,ART + 'feature.jpg',FANART,'')
    Menu('[B][COLOR cornflowerblue]Tendências[/COLOR][/B]',BASEURL+'trending/?get=movies',5,ART + 'new.jpg',FANART,'')
    Menu('[B][COLOR cornflowerblue]Gêneros[/COLOR][/B]',BASEURL,3,ART + 'genres.jpg',FANART,'')
    Menu('[B][COLOR cornflowerblue]Ano de Lançamento[/COLOR][/B]',BASEURL,4,ART + 'release.jpg',FANART,'')
    Menu('[B][COLOR cornflowerblue]IMDB Top Filmes[/COLOR][/B]',BASEURL+'top-imdb/',7,ART + 'imdb.jpg',FANART,'')
    Menu('[B][COLOR cornflowerblue]Procurar Filme[/COLOR][/B]','url',6,ART + 'search.jpg',FANART,'')
    Menu('[B][COLOR red]Novelas / Séries[/COLOR][/B]',BASEURL+'/tvshows/',8,ART + 'tvshows.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Genres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<ul class="genres scrolling">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)" >(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            name = name.replace('&#8211;','-').replace('\\xc2\\x80','').replace('\\xc2\\x81','').replace('\\xc2\\x82','').replace('\\xc2\\x83','').replace('\\xc2\\x84','').replace('\\xc2\\x85','').replace('\\xc2\\x86','').replace('\\xc2\\x87','').replace('\\xc2\\x88','').replace('\\xc2\\x89','').replace('\\xc2\\x8a','').replace('\\xc2\\x8b','').replace('\\xc2\\x8c','').replace('\\xc2\\x8d','').replace('\\xc2\\x8e','').replace('\\xc2\\x8f','').replace('\\xc2\\x90','').replace('\\xc2\\x91','').replace('\\xc2\\x92','').replace('\\xc2\\x93','').replace('\\xc2\\x94','').replace('\\xc2\\x95','').replace('\\xc2\\x96','').replace('\\xc2\\x97','').replace('\\xc2\\x98','').replace('\\xc2\\x99','').replace('\\xc2\\x9a','').replace('\\xc2\\x9b','').replace('\\xc2\\x9c','').replace('\\xc2\\x9d','').replace('\\xc2\\x9e','').replace('\\xc2\\x9f','').replace('\\xc2\\xa0','').replace('\\xc2\\xa1','¡').replace('\\xc2\\xa2','¢').replace('\\xc2\\xa3','£').replace('\\xc2\\xa4','¤').replace('\\xc2\\xa5','¥').replace('\\xc2\\xa6','¦').replace('\\xc2\\xa7','§').replace('\\xc2\\xa8','¨').replace('\\xc2\\xa9','©').replace('\\xc2\\xaa','ª').replace('\\xc2\\xab','«').replace('\\xc2\\xac','¬').replace('\\xc2\\xad','').replace('\\xc2\\xae','®').replace('\\xc2\\xaf','¯').replace('\\xc2\\xb0','°').replace('\\xc2\\xb1','±').replace('\\xc2\\xb2','²').replace('\\xc2\\xb3','³').replace('\\xc2\\xb4','´').replace('\\xc2\\xb5','µ').replace('\\xc2\\xb6','¶').replace('\\xc2\\xb7','·').replace('\\xc2\\xb8','¸').replace('\\xc2\\xb9','¹').replace('\\xc2\\xba','º').replace('\\xc2\\xbb','»').replace('\\xc2\\xbc','¼').replace('\\xc2\\xbd','½').replace('\\xc2\\xbe','¾').replace('\\xc2\\xbf','¿').replace('\\xc3\\x80','À').replace('\\xc3\\x81','Á').replace('\\xc3\\x82','Â').replace('\\xc3\\x83','Ã').replace('\\xc3\\x84','Ä').replace('\\xc3\\x85','Å').replace('\\xc3\\x86','Æ').replace('\\xc3\\x87','Ç').replace('\\xc3\\x88','È').replace('\\xc3\\x89','É').replace('\\xc3\\x8a','Ê').replace('\\xc3\\x8b','Ë').replace('\\xc3\\x8c','Ì').replace('\\xc3\\x8d','Í').replace('\\xc3\\x8e','Î').replace('\\xc3\\x8f','Ï').replace('\\xc3\\x90','Ð').replace('\\xc3\\x91','Ñ').replace('\\xc3\\x92','Ò').replace('\\xc3\\x93','Ó').replace('\\xc3\\x94','Ô').replace('\\xc3\\x95','Õ').replace('\\xc3\\x96','Ö').replace('\\xc3\\x97','×').replace('\\xc3\\x98','Ø').replace('\\xc3\\x99','Ù').replace('\\xc3\\x9a','Ú').replace('\\xc3\\x9b','Û').replace('\\xc3\\x9c','Ü').replace('\\xc3\\x9d','Ý').replace('\\xc3\\x9e','Þ').replace('\\xc3\\x9f','ß').replace('\\xc3\\xa0','à').replace('\\xc3\\xa1','á').replace('\\xc3\\xa2','â').replace('\\xc3\\xa3','ã').replace('\\xc3\\xa4','ä').replace('\\xc3\\xa5','å').replace('\\xc3\\xa6','æ').replace('\\xc3\\xa7','ç').replace('\\xc3\\xa8','è').replace('\\xc3\\xa9','é').replace('\\xc3\\xaa','ê').replace('\\xc3\\xab','ë').replace('\\xc3\\xac','ì').replace('\\xc3\\xad','í').replace('\\xc3\\xae','î').replace('\\xc3\\xaf','ï').replace('\\xc3\\xb0','ð').replace('\\xc3\\xb1','ñ').replace('\\xc3\\xb2','ò').replace('\\xc3\\xb3','ó').replace('\\xc3\\xb4','ô').replace('\\xc3\\xb5','õ').replace('\\xc3\\xb6','ö').replace('\\xc3\\xb7','÷').replace('\\xc3\\xb8','ø').replace('\\xc3\\xb9','ù').replace('\\xc3\\xba','ú').replace('\\xc3\\xbb','û').replace('\\xc3\\xbc','ü').replace('\\xc3\\xbd','ý').replace('\\xc3\\xbe','þ').replace('\\xc3\\xbf','ÿ')
            Menu('[B][COLOR cornflowerblue]%s[/COLOR][/B]' %name,url,5,ICON,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Years(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<ul class="year scrolling">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li><a href="(.+?)">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            Menu('[B][COLOR cornflowerblue]%s[/COLOR][/B]' %name,url,5,ICON,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
	
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<article class="item movies" id=".+?".+?<a href="(.+?)"><img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            icon = icon.replace('w185','w300_and_h450_bestv2')
            name = name.replace('&#8211;','-').replace('&#8217;','').replace('#038;','').replace('\\xc3\\xa9','e')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    np = re.compile('class="current".+?<a href=\'(.+?)\'',re.DOTALL).findall(OPEN)
    for url in np:
                    Menu('[B][COLOR blue]Próxima Página >[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_imdb(url):
    OPEN = Open_Url(url)
    Regex = re.compile('</i> Movies</h3>(.+?)<div class="top-imdb-list">',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<div class="image">.+?<img src="(.+?)" /></a>.+?<a href="(.+?)">(.+?)</a></div>',re.DOTALL).findall(str(Regex))
    for icon,url,name in Regex2:
            icon = icon.replace('w90','w300_and_h450_bestv2')
            name = name.replace('&#8211;','-').replace('\\xc2\\x80','').replace('\\xc2\\x81','').replace('\\xc2\\x82','').replace('\\xc2\\x83','').replace('\\xc2\\x84','').replace('\\xc2\\x85','').replace('\\xc2\\x86','').replace('\\xc2\\x87','').replace('\\xc2\\x88','').replace('\\xc2\\x89','').replace('\\xc2\\x8a','').replace('\\xc2\\x8b','').replace('\\xc2\\x8c','').replace('\\xc2\\x8d','').replace('\\xc2\\x8e','').replace('\\xc2\\x8f','').replace('\\xc2\\x90','').replace('\\xc2\\x91','').replace('\\xc2\\x92','').replace('\\xc2\\x93','').replace('\\xc2\\x94','').replace('\\xc2\\x95','').replace('\\xc2\\x96','').replace('\\xc2\\x97','').replace('\\xc2\\x98','').replace('\\xc2\\x99','').replace('\\xc2\\x9a','').replace('\\xc2\\x9b','').replace('\\xc2\\x9c','').replace('\\xc2\\x9d','').replace('\\xc2\\x9e','').replace('\\xc2\\x9f','').replace('\\xc2\\xa0','').replace('\\xc2\\xa1','¡').replace('\\xc2\\xa2','¢').replace('\\xc2\\xa3','£').replace('\\xc2\\xa4','¤').replace('\\xc2\\xa5','¥').replace('\\xc2\\xa6','¦').replace('\\xc2\\xa7','§').replace('\\xc2\\xa8','¨').replace('\\xc2\\xa9','©').replace('\\xc2\\xaa','ª').replace('\\xc2\\xab','«').replace('\\xc2\\xac','¬').replace('\\xc2\\xad','').replace('\\xc2\\xae','®').replace('\\xc2\\xaf','¯').replace('\\xc2\\xb0','°').replace('\\xc2\\xb1','±').replace('\\xc2\\xb2','²').replace('\\xc2\\xb3','³').replace('\\xc2\\xb4','´').replace('\\xc2\\xb5','µ').replace('\\xc2\\xb6','¶').replace('\\xc2\\xb7','·').replace('\\xc2\\xb8','¸').replace('\\xc2\\xb9','¹').replace('\\xc2\\xba','º').replace('\\xc2\\xbb','»').replace('\\xc2\\xbc','¼').replace('\\xc2\\xbd','½').replace('\\xc2\\xbe','¾').replace('\\xc2\\xbf','¿').replace('\\xc3\\x80','À').replace('\\xc3\\x81','Á').replace('\\xc3\\x82','Â').replace('\\xc3\\x83','Ã').replace('\\xc3\\x84','Ä').replace('\\xc3\\x85','Å').replace('\\xc3\\x86','Æ').replace('\\xc3\\x87','Ç').replace('\\xc3\\x88','È').replace('\\xc3\\x89','É').replace('\\xc3\\x8a','Ê').replace('\\xc3\\x8b','Ë').replace('\\xc3\\x8c','Ì').replace('\\xc3\\x8d','Í').replace('\\xc3\\x8e','Î').replace('\\xc3\\x8f','Ï').replace('\\xc3\\x90','Ð').replace('\\xc3\\x91','Ñ').replace('\\xc3\\x92','Ò').replace('\\xc3\\x93','Ó').replace('\\xc3\\x94','Ô').replace('\\xc3\\x95','Õ').replace('\\xc3\\x96','Ö').replace('\\xc3\\x97','×').replace('\\xc3\\x98','Ø').replace('\\xc3\\x99','Ù').replace('\\xc3\\x9a','Ú').replace('\\xc3\\x9b','Û').replace('\\xc3\\x9c','Ü').replace('\\xc3\\x9d','Ý').replace('\\xc3\\x9e','Þ').replace('\\xc3\\x9f','ß').replace('\\xc3\\xa0','à').replace('\\xc3\\xa1','á').replace('\\xc3\\xa2','â').replace('\\xc3\\xa3','ã').replace('\\xc3\\xa4','ä').replace('\\xc3\\xa5','å').replace('\\xc3\\xa6','æ').replace('\\xc3\\xa7','ç').replace('\\xc3\\xa8','è').replace('\\xc3\\xa9','é').replace('\\xc3\\xaa','ê').replace('\\xc3\\xab','ë').replace('\\xc3\\xac','ì').replace('\\xc3\\xad','í').replace('\\xc3\\xae','î').replace('\\xc3\\xaf','ï').replace('\\xc3\\xb0','ð').replace('\\xc3\\xb1','ñ').replace('\\xc3\\xb2','ò').replace('\\xc3\\xb3','ó').replace('\\xc3\\xb4','ô').replace('\\xc3\\xb5','õ').replace('\\xc3\\xb6','ö').replace('\\xc3\\xb7','÷').replace('\\xc3\\xb8','ø').replace('\\xc3\\xb9','ù').replace('\\xc3\\xba','ú').replace('\\xc3\\xbb','û').replace('\\xc3\\xbc','ü').replace('\\xc3\\xbd','ý').replace('\\xc3\\xbe','þ').replace('\\xc3\\xbf','ÿ')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_TV(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<article class="item tvshows" id=".+?".+?<a href="(.+?)"><img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            icon = icon.replace('w185','w300_and_h450_bestv2')
            name = name.replace('&#8211;','-').replace('\\xc2\\x80','').replace('\\xc2\\x81','').replace('\\xc2\\x82','').replace('\\xc2\\x83','').replace('\\xc2\\x84','').replace('\\xc2\\x85','').replace('\\xc2\\x86','').replace('\\xc2\\x87','').replace('\\xc2\\x88','').replace('\\xc2\\x89','').replace('\\xc2\\x8a','').replace('\\xc2\\x8b','').replace('\\xc2\\x8c','').replace('\\xc2\\x8d','').replace('\\xc2\\x8e','').replace('\\xc2\\x8f','').replace('\\xc2\\x90','').replace('\\xc2\\x91','').replace('\\xc2\\x92','').replace('\\xc2\\x93','').replace('\\xc2\\x94','').replace('\\xc2\\x95','').replace('\\xc2\\x96','').replace('\\xc2\\x97','').replace('\\xc2\\x98','').replace('\\xc2\\x99','').replace('\\xc2\\x9a','').replace('\\xc2\\x9b','').replace('\\xc2\\x9c','').replace('\\xc2\\x9d','').replace('\\xc2\\x9e','').replace('\\xc2\\x9f','').replace('\\xc2\\xa0','').replace('\\xc2\\xa1','¡').replace('\\xc2\\xa2','¢').replace('\\xc2\\xa3','£').replace('\\xc2\\xa4','¤').replace('\\xc2\\xa5','¥').replace('\\xc2\\xa6','¦').replace('\\xc2\\xa7','§').replace('\\xc2\\xa8','¨').replace('\\xc2\\xa9','©').replace('\\xc2\\xaa','ª').replace('\\xc2\\xab','«').replace('\\xc2\\xac','¬').replace('\\xc2\\xad','').replace('\\xc2\\xae','®').replace('\\xc2\\xaf','¯').replace('\\xc2\\xb0','°').replace('\\xc2\\xb1','±').replace('\\xc2\\xb2','²').replace('\\xc2\\xb3','³').replace('\\xc2\\xb4','´').replace('\\xc2\\xb5','µ').replace('\\xc2\\xb6','¶').replace('\\xc2\\xb7','·').replace('\\xc2\\xb8','¸').replace('\\xc2\\xb9','¹').replace('\\xc2\\xba','º').replace('\\xc2\\xbb','»').replace('\\xc2\\xbc','¼').replace('\\xc2\\xbd','½').replace('\\xc2\\xbe','¾').replace('\\xc2\\xbf','¿').replace('\\xc3\\x80','À').replace('\\xc3\\x81','Á').replace('\\xc3\\x82','Â').replace('\\xc3\\x83','Ã').replace('\\xc3\\x84','Ä').replace('\\xc3\\x85','Å').replace('\\xc3\\x86','Æ').replace('\\xc3\\x87','Ç').replace('\\xc3\\x88','È').replace('\\xc3\\x89','É').replace('\\xc3\\x8a','Ê').replace('\\xc3\\x8b','Ë').replace('\\xc3\\x8c','Ì').replace('\\xc3\\x8d','Í').replace('\\xc3\\x8e','Î').replace('\\xc3\\x8f','Ï').replace('\\xc3\\x90','Ð').replace('\\xc3\\x91','Ñ').replace('\\xc3\\x92','Ò').replace('\\xc3\\x93','Ó').replace('\\xc3\\x94','Ô').replace('\\xc3\\x95','Õ').replace('\\xc3\\x96','Ö').replace('\\xc3\\x97','×').replace('\\xc3\\x98','Ø').replace('\\xc3\\x99','Ù').replace('\\xc3\\x9a','Ú').replace('\\xc3\\x9b','Û').replace('\\xc3\\x9c','Ü').replace('\\xc3\\x9d','Ý').replace('\\xc3\\x9e','Þ').replace('\\xc3\\x9f','ß').replace('\\xc3\\xa0','à').replace('\\xc3\\xa1','á').replace('\\xc3\\xa2','â').replace('\\xc3\\xa3','ã').replace('\\xc3\\xa4','ä').replace('\\xc3\\xa5','å').replace('\\xc3\\xa6','æ').replace('\\xc3\\xa7','ç').replace('\\xc3\\xa8','è').replace('\\xc3\\xa9','é').replace('\\xc3\\xaa','ê').replace('\\xc3\\xab','ë').replace('\\xc3\\xac','ì').replace('\\xc3\\xad','í').replace('\\xc3\\xae','î').replace('\\xc3\\xaf','ï').replace('\\xc3\\xb0','ð').replace('\\xc3\\xb1','ñ').replace('\\xc3\\xb2','ò').replace('\\xc3\\xb3','ó').replace('\\xc3\\xb4','ô').replace('\\xc3\\xb5','õ').replace('\\xc3\\xb6','ö').replace('\\xc3\\xb7','÷').replace('\\xc3\\xb8','ø').replace('\\xc3\\xb9','ù').replace('\\xc3\\xba','ú').replace('\\xc3\\xbb','û').replace('\\xc3\\xbc','ü').replace('\\xc3\\xbd','ý').replace('\\xc3\\xbe','þ').replace('\\xc3\\xbf','ÿ')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,9,icon,FANART,'')
    np = re.compile('class="current".+?<a href=\'(.+?)\'',re.DOTALL).findall(OPEN)
    for url in np:
                    Menu('[B][COLOR blue]Próxima Página >[/COLOR][/B]',url,8,ART + 'nextpage.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_show_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="imagen">.+?<img src="(.+?)"></a>.+?<div class="numerando">(.+?)</div>.+?<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for icon,name1,url,name2 in Regex:
            name = name1+'   '+name2
            name = name.replace('&#8211;','-').replace('\\xc2\\x80','').replace('\\xc2\\x81','').replace('\\xc2\\x82','').replace('\\xc2\\x83','').replace('\\xc2\\x84','').replace('\\xc2\\x85','').replace('\\xc2\\x86','').replace('\\xc2\\x87','').replace('\\xc2\\x88','').replace('\\xc2\\x89','').replace('\\xc2\\x8a','').replace('\\xc2\\x8b','').replace('\\xc2\\x8c','').replace('\\xc2\\x8d','').replace('\\xc2\\x8e','').replace('\\xc2\\x8f','').replace('\\xc2\\x90','').replace('\\xc2\\x91','').replace('\\xc2\\x92','').replace('\\xc2\\x93','').replace('\\xc2\\x94','').replace('\\xc2\\x95','').replace('\\xc2\\x96','').replace('\\xc2\\x97','').replace('\\xc2\\x98','').replace('\\xc2\\x99','').replace('\\xc2\\x9a','').replace('\\xc2\\x9b','').replace('\\xc2\\x9c','').replace('\\xc2\\x9d','').replace('\\xc2\\x9e','').replace('\\xc2\\x9f','').replace('\\xc2\\xa0','').replace('\\xc2\\xa1','¡').replace('\\xc2\\xa2','¢').replace('\\xc2\\xa3','£').replace('\\xc2\\xa4','¤').replace('\\xc2\\xa5','¥').replace('\\xc2\\xa6','¦').replace('\\xc2\\xa7','§').replace('\\xc2\\xa8','¨').replace('\\xc2\\xa9','©').replace('\\xc2\\xaa','ª').replace('\\xc2\\xab','«').replace('\\xc2\\xac','¬').replace('\\xc2\\xad','').replace('\\xc2\\xae','®').replace('\\xc2\\xaf','¯').replace('\\xc2\\xb0','°').replace('\\xc2\\xb1','±').replace('\\xc2\\xb2','²').replace('\\xc2\\xb3','³').replace('\\xc2\\xb4','´').replace('\\xc2\\xb5','µ').replace('\\xc2\\xb6','¶').replace('\\xc2\\xb7','·').replace('\\xc2\\xb8','¸').replace('\\xc2\\xb9','¹').replace('\\xc2\\xba','º').replace('\\xc2\\xbb','»').replace('\\xc2\\xbc','¼').replace('\\xc2\\xbd','½').replace('\\xc2\\xbe','¾').replace('\\xc2\\xbf','¿').replace('\\xc3\\x80','À').replace('\\xc3\\x81','Á').replace('\\xc3\\x82','Â').replace('\\xc3\\x83','Ã').replace('\\xc3\\x84','Ä').replace('\\xc3\\x85','Å').replace('\\xc3\\x86','Æ').replace('\\xc3\\x87','Ç').replace('\\xc3\\x88','È').replace('\\xc3\\x89','É').replace('\\xc3\\x8a','Ê').replace('\\xc3\\x8b','Ë').replace('\\xc3\\x8c','Ì').replace('\\xc3\\x8d','Í').replace('\\xc3\\x8e','Î').replace('\\xc3\\x8f','Ï').replace('\\xc3\\x90','Ð').replace('\\xc3\\x91','Ñ').replace('\\xc3\\x92','Ò').replace('\\xc3\\x93','Ó').replace('\\xc3\\x94','Ô').replace('\\xc3\\x95','Õ').replace('\\xc3\\x96','Ö').replace('\\xc3\\x97','×').replace('\\xc3\\x98','Ø').replace('\\xc3\\x99','Ù').replace('\\xc3\\x9a','Ú').replace('\\xc3\\x9b','Û').replace('\\xc3\\x9c','Ü').replace('\\xc3\\x9d','Ý').replace('\\xc3\\x9e','Þ').replace('\\xc3\\x9f','ß').replace('\\xc3\\xa0','à').replace('\\xc3\\xa1','á').replace('\\xc3\\xa2','â').replace('\\xc3\\xa3','ã').replace('\\xc3\\xa4','ä').replace('\\xc3\\xa5','å').replace('\\xc3\\xa6','æ').replace('\\xc3\\xa7','ç').replace('\\xc3\\xa8','è').replace('\\xc3\\xa9','é').replace('\\xc3\\xaa','ê').replace('\\xc3\\xab','ë').replace('\\xc3\\xac','ì').replace('\\xc3\\xad','í').replace('\\xc3\\xae','î').replace('\\xc3\\xaf','ï').replace('\\xc3\\xb0','ð').replace('\\xc3\\xb1','ñ').replace('\\xc3\\xb2','ò').replace('\\xc3\\xb3','ó').replace('\\xc3\\xb4','ô').replace('\\xc3\\xb5','õ').replace('\\xc3\\xb6','ö').replace('\\xc3\\xb7','÷').replace('\\xc3\\xb8','ø').replace('\\xc3\\xb9','ù').replace('\\xc3\\xba','ú').replace('\\xc3\\xbb','û').replace('\\xc3\\xbc','ü').replace('\\xc3\\xbd','ý').replace('\\xc3\\xbe','þ').replace('\\xc3\\xbf','ÿ')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,iconimage,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

	
def Get_links(name,url):
    OPEN = Open_Url(url)
    trailer = re.compile('<iframe.+?src="https://www.youtube.com/embed/(.+?)\?rel=0&amp;controls=1&amp;showinfo=0&autoplay=0"',re.DOTALL).findall(OPEN)
    for url in trailer:
            Play('[B][COLOR red]Assistir Trailer[/COLOR][/B]','plugin://plugin.video.youtube/play/?video_id=%s'%url,100,iconimage,FANART,name)
    Regex = re.compile('file:"(.+?)".+?label:"(.+?)"',re.DOTALL).findall(OPEN)
    for url,name2 in Regex:
            Play('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')	

def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '/?s=' + search
                search_res(url)
    
def search_res(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="result-item">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
            name = name.replace('&#8211;','-').replace('&#8217;','').replace('#038;','')
            icon = icon.replace('-150x150','')
            Menu('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')  
	
########################################

def Open_Url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def Menu(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        

		
def Play(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
		
def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
		

def resolve(name,url,iconimage,description):
    name = description
    xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Attempting[/COLOR],[COLOR cornflowerblue]To Resolve Link[/COLOR] ,2000)")
         
    try: 
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
            liz.setProperty('IsPlayable','true')
            xbmc.Player().play(play,liz)
    except:
        play=xbmc.Player(GetPlayerCore())
        play.play(url,liz)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
#########################################################
	
if mode == None: Main_menu()
elif mode == 3: Get_Genres(url)
elif mode == 4: Get_Years(url)
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 7 : Get_imdb(url)
elif mode == 8 : Get_TV(url)
elif mode == 9 : Get_show_content(url)
elif mode == 10 : Get_links(name,url)
elif mode == 100 : resolve(name,url,iconimage,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
