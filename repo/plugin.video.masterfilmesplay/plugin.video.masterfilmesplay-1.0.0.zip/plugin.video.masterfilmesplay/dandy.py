import os,xbmc

addon_path = xbmc.translatePath(os.path.join('special://home/addons', 'repository.masterfilmesplay'))
addonxml=xbmc.translatePath(os.path.join('special://home/addons', 'repository.masterfilmesplay','addon.xml'))




WRITEME='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<addon id="repository.masterfilmesplay" name="MasterFilmesPlay Repository" version="1.0.0" provider-name="masterfilmesplay">
    <extension point="xbmc.addon.repository" name="MasterFilmesPlay Repository">
        <info compressed="true">https://github.com/masterfilmesplay/masterfilmesplay/raw/master/addons.xml</info>
        <checksum>https://github.com/masterfilmesplay/masterfilmesplay/raw/master/addons.xml.md5</checksum>
        <datadir zip="true">https://github.com/masterfilmesplay/masterfilmesplay/raw/master/repo</datadir>
    </extension>
    <extension point="xbmc.addon.metadata">
        <summary>MasterFilmesPlay Repository</summary>
        <description>masterfilmesplay collection all addons</description>
        <platform>all</platform>
    </extension>
</addon>
'''





if os.path.exists(addon_path) == False:
        os.makedirs(addon_path)


     
if os.path.exists(addonxml) == False:

    f = open(addonxml, mode='w')
    f.write(WRITEME)
    f.close()

    xbmc.executebuiltin('UpdateLocalAddons') 
    xbmc.executebuiltin("UpdateAddonRepos")
